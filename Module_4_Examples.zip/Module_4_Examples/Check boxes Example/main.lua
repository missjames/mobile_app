-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

local widget = require( "widget" )
 
-- Handle press events for the checkbox
local function onSwitchPress( event )
    local switch = event.target
    print( "Switch with ID '"..switch.id.."' is on: "..tostring(switch.isOn) )
end
 
-- Create the widget
local checkboxButton = widget.newSwitch(
    {
        x = display.contentCenterX,
        y = display.contentCenterY,         
        style = "checkbox",
        id = "Checkbox",
        onPress = onSwitchPress
    }
)
