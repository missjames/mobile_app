-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

local defaultBox
 
local function textListener( event )
 
    if ( event.phase == "began" ) then
        -- User begins editing "defaultBox"
 
    elseif ( event.phase == "ended" or event.phase == "submitted" ) then
        -- Output resulting text from "defaultBox"
        print( event.target.text )
 
    elseif ( event.phase == "editing" ) then
        print( event.newCharacters )
        print( event.oldText )
        print( event.startPosition )
        print( event.text )
    end
end
 
-- Create text box
defaultBox = native.newTextBox( 150, 200, 180, 140 )
defaultBox.text = "This is line 1.\nAnd this is line2"
defaultBox.isEditable = true
defaultBox:addEventListener( "userInput", textListener )
