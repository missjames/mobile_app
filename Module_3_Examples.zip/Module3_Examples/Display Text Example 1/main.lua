-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myText = display.newText( "Hello World!", display.contentCenterX, display.contentCenterY-100, native.systemFont, 30 )
myText:setFillColor( 1, 1, 0 )

local myText = display.newText( "hello", 50, 50, native.systemFont, 12 )
myText:setFillColor( 1, 0, 0.5 )
 
-- Change the displayed text
myText.text = "New Text"
 
-- Increase the font size
myText.size = 16
