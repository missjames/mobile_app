-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require( "widget" )
local counter = 0
local myText = display.newText( "Original Text!", display.contentCenterX, display.contentCenterY-100, native.systemFont, 30 )

myText:setFillColor( 1, 1, 0.5)


-- Function to handle button events
local function handleButtonEvent( event )
    
    if ( "ended" == event.phase ) then
       counter = counter + 1
        print( "Button was pressed and released" )
        print (counter)
        if ( counter % 2 == 0) then 
        myText.text = "Original Text!"
        myText.size = 30
        myText:setFillColor( 1, 1, 0.5 )
        else
        myText.text = "New Text!"
        myText.size = 40
        myText:setFillColor( 1, 0, 1 )
        end 
    end
end
 
 clickbutton = widget.newButton{
        id = "clickbutton",
        label = "Click",
        labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } }, 
        emboss=true,
        width = 100,
        height = 100,
        fontSize = 30,
        defaultFile = "buttonDefault.png",
        overFile = "button_Over.png",
        onEvent = handleButtonEvent
    }
-- Center the button
clickbutton.x = display.contentCenterX
clickbutton.y = display.contentCenterY
