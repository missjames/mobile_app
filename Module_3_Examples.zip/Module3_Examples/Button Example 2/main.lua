-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require( "widget" )
 
-- Function to handle button events
local function handleButtonEvent( event )
 
    if ( "ended" == event.phase ) then
        print( "Button was pressed and released" )
    end
end

 
 playBtn = widget.newButton{
        id = "playbutton",
        label = "Play",
        labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } }, 
        emboss=true,
        width = 100,
        height = 100,
        fontSize = 30,
        defaultFile = "buttonDefault.png",
        overFile = "button_Over.png",
        onEvent = handleButtonEvent
    }
-- Center the button
playBtn.x = display.contentCenterX
playBtn.y = display.contentCenterY
