-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

local widget = require( "widget" )
local counter = 0
local myText = display.newText( "Original Text!", display.contentCenterX, display.contentCenterY+100, native.systemFont, 30 )
local inputText = native.newTextField( display.contentCenterX, display.contentCenterY-100, 180, 30 )

myText:setFillColor( 1, 1, 0.5)

-- Function to handle button events
local function handleButtonEvent( event )
    
    if ( "ended" == event.phase ) then
       if (inputText.text == "") then 
            myText.text = "Please Enter a Value"
            myText:setFillColor( 1, 0, 0.5)
       else
            myText.text = inputText.text
            myText:setFillColor( 1, 1, 0.5)
       end 
    end
end
 
 clickbutton = widget.newButton{
        id = "clickbutton",
        label = "Click",
        labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } }, 
        emboss=true,
        width = 100,
        height = 100,
        fontSize = 30,
        defaultFile = "buttonDefault.png",
        overFile = "button_Over.png",
        onEvent = handleButtonEvent
    }
-- Center the button
clickbutton.x = display.contentCenterX
clickbutton.y = display.contentCenterY
