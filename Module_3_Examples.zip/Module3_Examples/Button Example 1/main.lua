-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require( "widget" )
-- Function to handle button events
local function handleButtonEvent( event )
if ( "ended" == event.phase ) then
print( "Button was pressed and released" )
end
end
-- Create the widget
local button1 = widget.newButton(
{
x = display.contentCenterX,
y = display.contentCenterY,
id = "button1",
label = "Default",
onEvent = handleButtonEvent
}
)