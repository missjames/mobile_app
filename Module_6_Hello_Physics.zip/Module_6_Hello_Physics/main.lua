-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local physics = require( "physics" )
physics.start()
local sky = display.newImage( "bkg_clouds.png", 160, 195 )
local ground = display.newImage( "ground.png", 160, 445 )
physics.addBody( ground, "static", { friction=0.5, bounce=0.3 } )
local crate = display.newImage( "crate.png", 180, -50 )
crate.rotation = 15
physics.addBody( crate, { density=3.0, friction=0.5, bounce=0.3 } )
