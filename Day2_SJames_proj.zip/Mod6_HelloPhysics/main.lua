-----------------------------------------------------------------------------------------
-- main.lua
-----------------------------------------------------------------------------------------
-- image files: bird.png, bkg_clouds.png, crate.png, ground.png
-----------------------------------------------------------------------------------------
-- make a reference to the physics library
local physics = require("physics")
physics.start()
--[[
local sky = display.newImage("bkg_clouds.png", 160, 195)
local ground = display.newImage("ground.png", 160, 445)

-- add physics property to the ground image
physics.addBody(ground,"static",{friction=0.5,bounce=0.3})

local bird = display.newImage("bird.png", 180, 50)
local bird2 = display.newImage("bird.png", 100, 50)
local crate = display.newImage("crate.png", 160, 400)
local ss = display.newImageRect("ss.jpg",60,60)
ss.x = 160--display.contentCenterX
ss.y = 328--display.contentCenterY

bird.rotation = 10
bird2.rotation = 50

physics.addBody(bird,{density=1.0,friction=0.7,bounce=0.5})
physics.addBody(bird2,{density=3.0,friction=0.5,bounce=0.5})
physics.addBody(crate,{friction=0.5})
physics.addBody(ss,{density=1.0,friction=0.7,bounce=0.9})
--]]
--warrior muay thai gym featuring 2 fighters
local gym = display.newImage("gym.jpg", 160, 195)
local fighter1 = display.newImage("fighter_1.gif",80,350)
local fighter2= display.newImageRect("moon2.png",90,150)
fighter2.x = 250--display.contentCenterX
fighter2.y = 350--display.contentCenterY
local disptxt = display.newText("Choose a fighter",display.contentCenterX,500,native.systemFont, 30)

--allow click and move for each fighter so we can move them around
function touch1( event )     
    if event.phase == "moved" then
		fighter1.x = event.x
		fighter1.y = event.y
	elseif event.phase == "ended" then
		disptxt.text = "GO Tom!"
		disptxt:setTextColor(0,0,255)
    end
end
function touch2( event )     
    if event.phase == "moved" then
		fighter2.x = event.x
		fighter2.y = event.y
	elseif event.phase == "ended" then
		disptxt.text = "GO Sailormoon!"
		disptxt:setTextColor(255,0,255)
    end
end
fighter1:addEventListener( "touch", touch1 )
fighter2:addEventListener( "touch", touch2 )

local blocksTable = {}
local tick = 2000  -- time between game loops in milliseconds
local hits1 = 3
local KO1 = 0
local hits2 = 3
local KO2 = 0
local died1=false
local died2=false
local numBlocks = 0
local explosion = audio.loadSound("sounds/explosion.wav")

-- Add initial hits and KO labels and counts
local function newText()
   textHitLabel = display.newText("Hits Remain", display.contentCenterX, 15, native.systemFont, 20)
   textKOLabel = display.newText("Lose by KO", display.contentCenterX, 40, native.systemFont, 20)
   textHitLabel:setTextColor(0,255,0)
   textKOLabel:setTextColor(0,255,0)
   
   textHits1 = display.newText(hits1, 20, 15, native.systemFont, 20)
   textHits2 = display.newText(hits2, 300, 15, native.systemFont, 20)
   textKO1 = display.newText(KO1, 20, 40, native.systemFont, 20)
   textKO2 = display.newText(KO2, 300, 40, native.systemFont, 20)
   
   textHits1:setTextColor(255,0,0)
   textHits2:setTextColor(255,0,0)
   textKO1:setTextColor(0,0,255)
   textKO2:setTextColor(0,0,255)
end

-- Update hits and KO labels and counts
local function updateText()
    textHits1.text = hits1 ..""
	textHits2.text = hits2 ..""
	textKO1.text = KO1 ..""
	textKO1.text = KO2 ..""
end

-- add blocks later
--local ss = display.newImageRect("ss.jpg",60,60)
--ss.x = 160--display.contentCenterX
--ss.y = 328--display.contentCenterY
--physics.addBody(ss,{density=1.0,friction=0.7,bounce=0.9})
local function loadBlocks()
	numBlocks= numBlocks +1
	blocksTable[numBlocks] = display.newImageRect("ss.jpg",60,60)
	physics.addBody(blocksTable[numBlocks],{density=1,friction=0.4,bounce=1})
	blocksTable[numBlocks].myName="block"
	
	-- blocksTable[numBlocks].x = -50
	-- blocksTable[numBlocks].y = (math.random(display.contentHeight *.75))
	-- transition.to(blocksTable[numBlocks], {x= (display.contentWidth +100),
	-- y=(math.random(display.contentHeight)), time =(math.random(5000, 10000))})
	
	blocksTable[numBlocks].x = (math.random(display.contentWidth))
	blocksTable[numBlocks].y = -30
	transition.to(blocksTable[numBlocks], {x= (math.random(display.contentWidth)),
	y=(display.contentHeight+100), time =(math.random(5000, 10000))})
	
	-- blocksTable[numBlocks].x = display.contentWidth+50
	-- blocksTable[numBlocks].y = (math.random(display.contentHeight *.75))
	-- transition.to(blocksTable[numBlocks], {x= -100,
	-- y=(math.random(display.contentHeight)), time =(math.random(5000, 10000))})
end

local function gameLoop()
	updateText()
	loadBlocks()
end
newText()
timer.performWithDelay(tick, gameLoop,0)