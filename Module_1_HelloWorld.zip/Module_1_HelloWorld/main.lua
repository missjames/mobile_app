-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

print("Hello World")

local mytext = display.newText("Hello World", 150, 150, native.systemFont, 20)
mytext:setTextColor(0, 255, 0)