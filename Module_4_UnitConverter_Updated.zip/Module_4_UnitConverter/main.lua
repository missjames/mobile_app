-----------------------------------------------------------------------------------------

local widget = require( "widget" )

local image = display.newImageRect( "background.jpg",
               display.contentWidth, display.contentHeight) 
image.x = display.contentCenterX
image.y = display.contentCenterY

local counter = 0
local mylabel = display.newText( "Meters", display.contentCenterX, display.contentCenterY-130, native.systemFont, 20 )

local myText = display.newText( "Inches", display.contentCenterX, display.contentCenterY+50, native.systemFont, 20 )

local inches = native.newTextField( display.contentCenterX, display.contentCenterY+80, 300, 30 )
inches.inputType = "number"

local meters = native.newTextField( display.contentCenterX, display.contentCenterY-100, 300, 30 )
meters.inputType = "number"


myText:setFillColor( 1, 1, 0.5)





-- Function to handle button events
local function meters2inches( event )
    
    if ( "ended" == event.phase ) then
       if (meters.text == "") then 
            -- inches.text = "Please Enter a Value"
            
       else
            num = meters.text
            inches.text = num*39.3701 .. ""
            
       end 
    end
end

-- Function to handle button events
local function inches2meters( event )
    
    if ( "ended" == event.phase ) then
       if (inches.text == "") then 
            -- meters.text = "Please Enter a Value"
            
       else
           num = inches.text
            meters.text = num/39.3701 .. ""
            
       end 
    end
end

 
 clickbutton_1 = widget.newButton{
        id = "clickbutton1",
        --label = "Click",
        labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } }, 
        emboss=true,
        width = 60,
        height = 60,
        fontSize = 20,
        defaultFile = "up.png",
        overFile = "up_over.png",
        onEvent = inches2meters
    }
-- Center the button
clickbutton_1.x = display.contentCenterX-50
clickbutton_1.y = display.contentCenterY-20
 
 clickbutton_2 = widget.newButton{
        id = "clickbutton2",
        --label = "Click",
        labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } }, 
        emboss=true,
        width = 60,
        height = 60,
        fontSize = 20,
        defaultFile = "down.png",
        overFile = "down_over.png",
        onEvent = meters2inches
    }
-- Center the button
clickbutton_2.x = display.contentCenterX+50
clickbutton_2.y = display.contentCenterY-20


