-----------------------------------------------------------------------------------------

local widget = require( "widget" )

local image = display.newImageRect( "background.jpg",
               display.contentWidth, display.contentHeight) 
image.x = display.contentCenterX
image.y = display.contentCenterY

local counter = 0
local mylabel = display.newText( "Unit Converter", display.contentCenterX, display.contentCenterY-180, native.systemFont, 20 )

local myText = display.newText( "Original Text!", display.contentCenterX, display.contentCenterY+160, native.systemFont, 20 )

local inputText = native.newTextField( display.contentCenterX, display.contentCenterY-100, 300, 30 )
inputText.inputType = "number"

myText:setFillColor( 1, 1, 0.5)





-- Function to handle button events
local function handleButtonEvent1( event )
    
    if ( "ended" == event.phase ) then
       if (inputText.text == "") then 
            myText.text = "Please Enter a Value"
            myText:setFillColor( 1, 0, 0.5)
       else
            num = inputText.text
            myText.text = num*39.3701 .. " inch"
            myText:setFillColor( 1, 1, 0.5)
       end 
    end
end

-- Function to handle button events
local function handleButtonEvent2( event )
    
    if ( "ended" == event.phase ) then
       if (inputText.text == "") then 
            myText.text = "Please Enter a Value"
            myText:setFillColor( 1, 0, 0.5)
       else
           num = inputText.text
            myText.text = num/39.3701 .. " meter"
            myText:setFillColor( 1, 1, 0.5)
       end 
    end
end

 
 clickbutton_1 = widget.newButton{
        id = "clickbutton1",
        --label = "Click",
        labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } }, 
        emboss=true,
        width = 300,
        height = 60,
        fontSize = 20,
        defaultFile = "but1.png",
        overFile = "but1_over.png",
        onEvent = handleButtonEvent1
    }
-- Center the button
clickbutton_1.x = display.contentCenterX
clickbutton_1.y = display.contentCenterY-20
 
 clickbutton_2 = widget.newButton{
        id = "clickbutton2",
        --label = "Click",
        labelColor = { default={ 1, 1, 1 }, over={ 0, 0, 0, 0.5 } }, 
        emboss=true,
        width = 300,
        height = 60,
        fontSize = 20,
        defaultFile = "but2.png",
        overFile = "but2_over.png",
        onEvent = handleButtonEvent2
    }
-- Center the button
clickbutton_2.x = display.contentCenterX
clickbutton_2.y = display.contentCenterY+60


